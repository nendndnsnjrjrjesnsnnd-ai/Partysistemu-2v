package dev.pvpcore.party.match;

import dev.pvpcore.party.PartyPlugin;
import dev.pvpcore.party.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.AreaEffectCloud;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.AreaEffectCloudApplyEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPlaceEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.PotionSplashEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public final class MatchListener implements Listener {
    /** Takim arkadasina uygulanmamasi gereken zararli iksir etkileri. */
    private static final Set<PotionEffectType> HARMFUL = Set.of(
            PotionEffectType.SLOWNESS, PotionEffectType.WEAKNESS, PotionEffectType.POISON,
            PotionEffectType.WITHER, PotionEffectType.INSTANT_DAMAGE, PotionEffectType.BLINDNESS,
            PotionEffectType.NAUSEA, PotionEffectType.HUNGER, PotionEffectType.LEVITATION,
            PotionEffectType.MINING_FATIGUE, PotionEffectType.DARKNESS);

    private final PartyPlugin plugin;

    public MatchListener(PartyPlugin plugin) {
        this.plugin = plugin;
    }

    private PartyMatch matchOf(Entity e) {
        return e instanceof Player p ? plugin.matches().of(p.getUniqueId()) : null;
    }

    /**
     * Hasari kimin verdigini bulur: oyuncu, ok/iksir/kar topu gibi mermiler, TNT, kalici iksir bulutu
     * ve (maca ozel takip edilen) end crystal.
     */
    private Player resolveAttacker(Entity damager, PartyMatch m) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile proj && proj.getShooter() instanceof Player p) return p;
        if (damager instanceof TNTPrimed tnt && tnt.getSource() instanceof Player p) return p;
        if (damager instanceof AreaEffectCloud cloud && cloud.getSource() instanceof Player p) return p;
        if (damager instanceof EnderCrystal crystal && m != null) {
            UUID owner = m.crystalOwner(crystal.getUniqueId());
            if (owner != null) return Bukkit.getPlayer(owner);
        }
        return null;
    }

    private static boolean hasTotem(Player p) {
        PlayerInventory inv = p.getInventory();
        return inv.getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING
                || inv.getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING;
    }

    private static boolean harmful(Collection<PotionEffect> effects) {
        if (effects == null) return false;
        for (PotionEffect pe : effects) {
            if (HARMFUL.contains(pe.getType())) return true;
        }
        return false;
    }

    // ------------------------------------------------------------- hasar / olum

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        PartyMatch m = plugin.matches().of(victim.getUniqueId());

        Player attacker = null;
        if (e instanceof EntityDamageByEntityEvent be) attacker = resolveAttacker(be.getDamager(), m);

        if (m == null) {
            // Macta olan biri mac disindakine vuramaz
            if (attacker != null && plugin.matches().inMatch(attacker.getUniqueId())) e.setCancelled(true);
            return;
        }
        if (m.state() != PartyMatch.State.FIGHTING || !m.isAlive(victim.getUniqueId())) {
            e.setCancelled(true);
            return;
        }
        if (attacker != null) {
            PartyMatch am = plugin.matches().of(attacker.getUniqueId());
            if (am != m || !m.isAlive(attacker.getUniqueId())) {
                e.setCancelled(true);
                return;
            }
            if (!attacker.getUniqueId().equals(victim.getUniqueId())
                    && m.sameTeam(attacker.getUniqueId(), victim.getUniqueId())) {
                e.setCancelled(true);
                attacker.sendActionBar(Text.c(plugin.lang().get("friendly-fire")));
                return;
            }
            m.recordDamager(victim.getUniqueId(), attacker.getUniqueId());
        }

        // Olumcul darbe: totem yoksa oyuncuyu olum ekrani olmadan elenmis say
        if (victim.getHealth() - e.getFinalDamage() > 0) return;
        if (hasTotem(victim)) return;
        e.setCancelled(true);
        m.eliminate(victim.getUniqueId(), m.lastDamager(victim.getUniqueId()), false);
    }

    /** Yedek: baska bir yolla olurse yine de temiz elensin. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        PartyMatch m = plugin.matches().of(p.getUniqueId());
        if (m == null) return;
        e.setKeepInventory(true);
        e.getDrops().clear();
        e.setDroppedExp(0);
        e.deathMessage(null);
        m.eliminate(p.getUniqueId(), m.lastDamager(p.getUniqueId()), false);
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (p.isDead()) p.spigot().respawn();
        });
    }

    // ------------------------------------------------- iksir / bulut / kristal

    /** Splash iksirinin zararli etkileri takim arkadasina ve mac disindakilere islemez. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSplash(PotionSplashEvent e) {
        if (!(e.getEntity().getShooter() instanceof Player thrower)) return;
        PartyMatch m = plugin.matches().of(thrower.getUniqueId());
        if (m == null) return;
        boolean bad = harmful(e.getEntity().getEffects());
        for (LivingEntity le : new ArrayList<>(e.getAffectedEntities())) {
            if (!(le instanceof Player v) || v.equals(thrower)) continue;
            PartyMatch vm = plugin.matches().of(v.getUniqueId());
            if (vm != m) {
                e.setIntensity(le, 0.0);
            } else if (bad && m.sameTeam(thrower.getUniqueId(), v.getUniqueId())) {
                e.setIntensity(le, 0.0);
            }
        }
    }

    /** Kalici (lingering) iksir bulutu takim arkadasina ve mac disindakilere islemez. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCloud(AreaEffectCloudApplyEvent e) {
        if (!(e.getEntity().getSource() instanceof Player owner)) return;
        PartyMatch m = plugin.matches().of(owner.getUniqueId());
        if (m == null) return;
        e.getAffectedEntities().removeIf(le -> le instanceof Player v
                && !v.equals(owner)
                && (plugin.matches().of(v.getUniqueId()) != m
                || m.sameTeam(owner.getUniqueId(), v.getUniqueId())));
    }

    /** End crystal koyan oyuncuyu kaydeder (patlama hasari kime ait?). */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCrystalPlace(EntityPlaceEvent e) {
        Player p = e.getPlayer();
        if (p == null || !(e.getEntity() instanceof EnderCrystal)) return;
        PartyMatch m = plugin.matches().of(p.getUniqueId());
        if (m != null) m.setCrystalOwner(e.getEntity().getUniqueId(), p.getUniqueId());
    }

    /** Crystal'e en son vuran oyuncu patlamanin sahibi sayilir. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCrystalHit(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof EnderCrystal crystal)) return;
        Player p = resolveAttacker(e.getDamager(), null);
        if (p == null) return;
        PartyMatch m = plugin.matches().of(p.getUniqueId());
        if (m != null) m.setCrystalOwner(crystal.getUniqueId(), p.getUniqueId());
    }

    // ------------------------------------------------------------ hareket / esya

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        PartyMatch m = plugin.matches().of(e.getPlayer().getUniqueId());
        if (m == null || m.state() != PartyMatch.State.COUNTDOWN) return;
        if (e.getTo() == null) return;
        if (e.getFrom().getX() != e.getTo().getX() || e.getFrom().getZ() != e.getTo().getZ()) {
            e.setTo(e.getFrom());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        PartyMatch m = plugin.matches().of(e.getPlayer().getUniqueId());
        if (m != null && m.state() != PartyMatch.State.FIGHTING) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onRegen(EntityRegainHealthEvent e) {
        PartyMatch m = matchOf(e.getEntity());
        if (m == null) return;
        EntityRegainHealthEvent.RegainReason r = e.getRegainReason();
        if ((r == EntityRegainHealthEvent.RegainReason.SATIATED || r == EntityRegainHealthEvent.RegainReason.REGEN)
                && !m.kit().naturalRegen()) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFood(FoodLevelChangeEvent e) {
        PartyMatch m = matchOf(e.getEntity());
        if (m == null) return;
        if (!m.kit().naturalSaturationDecrease() && e.getFoodLevel() < ((Player) e.getEntity()).getFoodLevel()) {
            e.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------ bloklar

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        PartyMatch m = plugin.matches().of(e.getPlayer().getUniqueId());
        if (m == null) return;
        if (m.state() != PartyMatch.State.FIGHTING || !m.isAlive(e.getPlayer().getUniqueId())) {
            e.setCancelled(true);
            return;
        }
        m.trackPlaced(e.getBlockPlaced());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        PartyMatch m = plugin.matches().of(e.getPlayer().getUniqueId());
        if (m == null) return;
        if (m.state() != PartyMatch.State.FIGHTING || !m.isAlive(e.getPlayer().getUniqueId())) {
            e.setCancelled(true);
            return;
        }
        if (m.untrackPlaced(e.getBlock())) return;
        if (!m.kit().canBreakBlock(e.getBlock().getType())) e.setCancelled(true);
    }

    // ------------------------------------------------------------ komut / cikis

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        PartyMatch m = plugin.matches().of(p.getUniqueId());
        if (m == null) return;

        String msg = e.getMessage().trim().toLowerCase(Locale.ROOT);
        if (msg.startsWith("/")) msg = msg.substring(1);
        String cmd = msg.split("\\s+")[0];
        int colon = cmd.indexOf(':');
        if (colon >= 0) cmd = cmd.substring(colon + 1);

        if (cmd.equals("p") || cmd.equals("party") || cmd.equals("parti")) return;

        if (cmd.equals("leave")) {
            e.setCancelled(true);
            plugin.send(p, "match-forfeit");
            m.leave(p.getUniqueId());
            return;
        }
        if (p.hasPermission("pvpcoreparty.bypass")) return;
        if (!plugin.core().settings().allowCommandsInMatch()) {
            e.setCancelled(true);
            plugin.send(p, "command-blocked");
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onQuit(PlayerQuitEvent e) {
        PartyMatch m = plugin.matches().of(e.getPlayer().getUniqueId());
        if (m != null) m.leave(e.getPlayer().getUniqueId());
    }
}
