package dev.pvpcore.party.util;

import dev.rean.pvpcore.model.Kit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.Locale;

/**
 * Parti menulerindeki kit ikonlarini kit adina gore secer.
 * Kit id'si veya gorunen adi anahtar kelimeyi iceriyorsa o esya kullanilir.
 * Siralama onemlidir: ustteki kural once denenir. config.yml > kit-icons ile degistirilebilir.
 */
public final class KitIcons {
    private static final String[][] DEFAULTS = {
            {"uhc", "GOLDEN_APPLE"},
            {"smp", "SHIELD"},
            {"mace", "MACE"},
            {"axe", "DIAMOND_AXE"},
            {"sword", "DIAMOND_SWORD"},
            {"vanilla", "END_CRYSTAL"},
            {"crystal", "END_CRYSTAL"},
            {"pot", "SPLASH_POTION"},
            {"netherite", "NETHERITE_HELMET"},
            {"neth", "NETHERITE_HELMET"}
    };

    private KitIcons() {}

    private static String clean(String s) {
        if (s == null) return "";
        return s.replaceAll("(?i)[&§]#[0-9a-f]{6}", "")
                .replaceAll("(?i)[&§][0-9a-fk-orx]", "")
                .replaceAll("<[^>]*>", "")
                .toLowerCase(Locale.ROOT);
    }

    public static Material of(FileConfiguration cfg, Kit kit) {
        String key = clean(kit.id()) + " " + clean(kit.displayName());

        ConfigurationSection sec = cfg.getConfigurationSection("kit-icons");
        if (sec != null) {
            for (String k : sec.getKeys(false)) {
                if (!key.contains(k.toLowerCase(Locale.ROOT))) continue;
                Material m = Material.matchMaterial(sec.getString(k, ""));
                if (m != null) return m;
            }
        }
        for (String[] d : DEFAULTS) {
            if (!key.contains(d[0])) continue;
            Material m = Material.matchMaterial(d[1]);
            if (m != null) return m;
        }
        return kit.icon() != null ? kit.icon().getType() : Material.IRON_SWORD;
    }
}
